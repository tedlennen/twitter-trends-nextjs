(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 659:
/***/ ((module) => {

// Exports
module.exports = {
	"table": "Twitter_table__Oo6t_",
	"table_desc": "Twitter_table_desc__iNq7_",
	"table_head": "Twitter_table_head__Nph4F",
	"table_row": "Twitter_table_row__UamMz",
	"anchor": "Twitter_anchor__5zh4W"
};


/***/ }),

/***/ 336:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./components/Twitter.module.css
var Twitter_module = __webpack_require__(659);
var Twitter_module_default = /*#__PURE__*/__webpack_require__.n(Twitter_module);
;// CONCATENATED MODULE: ./components/Twitter.js



const Twitter = (props)=>{
    const { 0: tweets , 1: setTweets  } = (0,external_react_.useState)(props.trends);
    const convertVolumeToShort = (volume)=>{
        if (volume > 1000000) return (volume / 1000000).toFixed(2) + "M";
        else if (volume > 1000) return (volume / 1000).toFixed(2) + "K";
        else return volume;
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                className: (Twitter_module_default()).table,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            className: (Twitter_module_default()).table_row,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: (Twitter_module_default()).table_head,
                                    children: "Rank"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: (Twitter_module_default()).table_head,
                                    children: "Name"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: (Twitter_module_default()).table_head,
                                    children: "Tweet Volume"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                        children: tweets === null || tweets === void 0 ? void 0 : tweets.map((tweet, index)=>{
                            return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                className: (Twitter_module_default()).table_row,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: (Twitter_module_default()).table_desc,
                                        children: index + 1
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: (Twitter_module_default()).table_desc,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: tweet.url,
                                            className: "anchor",
                                            children: tweet.name
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: (Twitter_module_default()).table_desc,
                                        children: tweet.tweet_volume ? convertVolumeToShort(tweet.tweet_volume) : "Under 10K"
                                    })
                                ]
                            }, index));
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const components_Twitter = (Twitter);

;// CONCATENATED MODULE: ./pages/index.js



const axios = __webpack_require__(167);
const Index = (props)=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Twitter Trends"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "This website displays 50 currently trending hashtags on twitter."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Twitter, {
                trends: props.trends
            })
        ]
    }));
};
async function getStaticProps() {
    const url = "https://api.twitter.com/1.1/trends/place.json?id=23424848";
    const token = "AAAAAAAAAAAAAAAAAAAAAFxeVwEAAAAAEAgJQcTvi8pO4D9eXx%2BBCz0yf2E%3DmkuCAx0wAMvZjDh0o8OS5ArFOj98GumE0c893QV2WivWM3f4BI";
    const config = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    const response = await axios(url, config);
    const trendsArray = response.data[0].trends;
    return {
        props: {
            trends: trendsArray
        },
        revalidate: 1800
    };
}
/* harmony default export */ const pages = (Index);


/***/ }),

/***/ 167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(336));
module.exports = __webpack_exports__;

})();